module.exports = {
  "automock": false,
  "moduleDirectories": [
    "node_modules",
    "src/javascript"
  ],
  "setupFiles": [
    "./test/support/enzyme.js"
  ],
  "testURL": "http://localhost/"
}