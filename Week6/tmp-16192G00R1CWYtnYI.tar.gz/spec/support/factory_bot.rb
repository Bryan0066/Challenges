require 'factory_bot'

FactoryBot.define do
  factory :starship do

  end
end
