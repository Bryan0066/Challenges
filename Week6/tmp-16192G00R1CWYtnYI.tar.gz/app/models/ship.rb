class Ship < ActiveRecord::Base

end