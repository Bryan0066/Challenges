import React from 'react'

export const App = (props) => {
  return (<h1>Make It So React</h1>)
}

export default App
