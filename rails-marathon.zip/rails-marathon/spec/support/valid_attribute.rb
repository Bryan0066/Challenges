require 'valid_attribute/rspec'
